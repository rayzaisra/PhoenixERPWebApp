function errorHandler(e) {
    if (e.status === 'customerror') {
        if (e.errors) {
            var message = '';
            $.each(e.errors, function (key, value) {
                title = key;
                if ('errors' in value) {
                    $.each(value.errors, function () {
                        message += this + "\n";
                    });
                }
            });

            $('.k-grid').each(function (item) {
                var grid = $(this).data("kendoGrid");
                if (e.sender === grid.dataSource) {
                    grid.cancelChanges();
                }
            });

            swal('Error', message, 'error');
        }
    } else if (e.status === "error") {
        swal('Error', e.xhr.responseJSON.errorMessage, 'error');
    }
}

function dataItem(e) {
    var $elem = $(e);
    var grid = $elem.closest("div[data-role='grid']").data("kendoGrid");
    var item = grid.dataItem($elem.closest("tr"));
    return item;
}

function refreshGrid(e) {
    var $elem = $(e);
    var grid = $elem.closest("div[data-role='grid']").data("kendoGrid");
    grid.dataSource.read();
}

function deleteRow(e, url) {
    var item = dataItem(e);
    swal({
        title: "Are you sure?",
        text: "You won't be able to revert this!",
        type: "warning",
        showCancelButton: !0,
        confirmButtonText: "Yes",
        cancelButtonText: "No",
        reverseButtons: !0
    }).then(function (ok) {
        if (ok.value) {
            mApp.block("#m_blockui_list", {
                overlayColor: "#000000",
                type: "loader",
                state: "primary",
                message: "Processing..."
            });
            $.ajax({
                type: "DELETE",
                url: url,
                data: JSON.parse(JSON.stringify(item)),
                success: function (result) {
                    if (result.success) {
                        swal('Information', result.message, 'success')
                            .then(function (ok) {
                                if (ok.value) {
                                    if (result.url !== undefined) { window.location = result.url } else { refreshGrid(e) };
                                }
                            });
                    } else {
                        swal('Error', result.message, 'error');
                    }
                    mApp.unblock("#m_blockui_list");
                },
                error: function (e, t, s) {
                    swal('Information', 'Ooops, something went wrong !', 'info');
                    mApp.unblock("#m_blockui_list");
                }
            }).then(setTimeout(function () {
                mApp.unblock("#m_blockui_list");
            }, 2e3));
        }
    }).catch(swal.noop);
}

function callAction(parameter) {
    if (parameter.formId !== undefined) {
        if (parameter.formId.substring(0, 1) !== "#") parameter.formId = "#" + parameter.formId;
        var valid = $(parameter.formId).validate().form();
        if (valid) {
            swal({
                title: "Confirmation",
                text: 'Are you sure want to ' + parameter.title + ' this data?',
                type: "question",
                showCancelButton: !0,
                confirmButtonText: "Yes",
                cancelButtonText: "No",
                reverseButtons: !0
            }).then(function (ok) {
                if (ok.value) {
                    mApp.block("#m_blockui_list", {
                        overlayColor: "#000000",
                        type: "loader",
                        state: "primary",
                        message: "Processing..."
                    });
                    var data = $(parameter.formId).serialize();
                    var url = parameter.url;
                    if (url === undefined) url = $(parameter.formId).attr('action');

                    $.ajax({
                        type: parameter.type,
                        url: url,
                        data: data,
                        success: function (result) {
                            if (result.success) {
                                swal('Information', result.message, 'success')
                                    .then(function (ok) {
                                        if (ok.value) {
                                            if (result.url !== undefined) window.location = result.url;
                                        }
                                    });
                            } else {
                                swal('Error', result.message, 'error');
                            }
                            mApp.unblock("#m_blockui_list");
                        },
                        error: function (e, t, s) {
                            swal('Information', 'Ooops, something went wrong !', 'info');
                            mApp.unblock("#m_blockui_list");
                        }
                    }).then(setTimeout(function () {
                        mApp.unblock("#m_blockui_list");
                    }, 2e3));
                }
            }).catch(swal.noop);
        }
    }
}

function callActionFile(parameter) {
    if (parameter.formId !== undefined) {
        if (parameter.formId.substring(0, 1) !== "#") parameter.formId = "#" + parameter.formId;
        var valid = $(parameter.formId).validate().form();
        if (valid) {
            swal({
                title: "Confirmation",
                text: 'Are you sure want to ' + parameter.title + ' this data?',
                type: "question",
                showCancelButton: !0,
                confirmButtonText: "Yes",
                cancelButtonText: "No",
                reverseButtons: !0
            }).then(function (ok) {
                if (ok.value) {
                    mApp.block("#m_blockui_list", {
                        overlayColor: "#000000",
                        type: "loader",
                        state: "primary",
                        message: "Processing..."
                    });
                    var formData = new FormData();
                    $.each($(parameter.formId).find("input[type='file']"), function (i, tag) {
                        $.each($(tag)[0].files, function (i, file) {
                            formData.append(tag.name, file);
                        });
                    });
                    var params = $(parameter.formId).serializeArray();
                    $.each(params, function (i, val) {
                        formData.append(val.name, val.value);
                    });

                    var url = parameter.url;
                    if (url === undefined) url = $(parameter.formId).attr('action');

                    $.ajax({
                        type: parameter.type,
                        url: url,
                        cache: false,
                        contentType: false,
                        processData: false,
                        data: formData,
                        success: function (result) {
                            if (result.success) {
                                swal('Information', result.message, 'success')
                                    .then(function (ok) {
                                        if (ok.value) {
                                            if (result.url !== undefined) window.location = result.url;
                                        }
                                    });
                            } else {
                                swal('Error', result.message, 'error');
                            }
                            mApp.unblock("#m_blockui_list");
                        },
                        error: function (e, t, s) {
                            swal('Information', 'Ooops, something went wrong !', 'info');
                            mApp.unblock("#m_blockui_list");
                        }
                    }).then(setTimeout(function () {
                        mApp.unblock("#m_blockui_list");
                    }, 2e3));
                }
            }).catch(swal.noop);
        }
    }
}


function comboboxSelectEvent(e) {
    var dataItem = e.dataItem;
    if (dataItem === null && dataItem === undefined)
        this.value("");
}

function downloadAction(parameter) {
    $.ajax({
        type: "GET",
        dataType: "json",
        contentType: "application/x-www-form-urlencoded",
        async: false,
        data: parameter.data,
        url: parameter.url,
        success: function (result) {
            if (result.File !== undefined) {
                kendo.saveAs({
                    dataURI: "data:text/plain;base64," + result.File,
                    fileName: result.FileName
                });

            }
        }
    });
}

var counter = 1;
function onDataBound(e) {
    counter = 1;
}

function renderNumber(data) {
    return counter++;
}    